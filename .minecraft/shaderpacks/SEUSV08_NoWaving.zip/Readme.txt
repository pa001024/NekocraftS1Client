Extract the contents of the folder within this archive to minecraft.jar/Shaders and overwrite the existing files there AFTER installing Sonic Ether's Unbelievable Shaders.

Enjoy!!!